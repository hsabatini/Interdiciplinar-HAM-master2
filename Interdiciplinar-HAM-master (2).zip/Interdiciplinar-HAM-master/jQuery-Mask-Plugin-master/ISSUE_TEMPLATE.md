### Have you take a look into our docs?
https://igorescobar.github.io/jQuery-Mask-Plugin/

### Make sure your read this before opening a new issue:
https://github.com/igorescobar/jQuery-Mask-Plugin#problems-or-questions

#### Device
[...]

#### Browser (and version)?
[...]

#### Functional `jsfiddle` exemplifying your problem: 
You can use this one as exemple: http://jsfiddle.net/igorescobar/6pco4om7/

#### Describe de problem depth:
[...]


Is this plugin helping you out? Buy me a beer and cheers! :beer:

:bowtie: https://www.paypal.me/igorcescobar
