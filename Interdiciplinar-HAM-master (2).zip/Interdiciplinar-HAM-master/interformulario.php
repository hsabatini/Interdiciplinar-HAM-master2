<!DOCTYPE html>
<html lang="br" dir="ltr">
<head>
  <meta charset="utf-8">
  <title> TELA DE LOGIN</title>
  <link rel="stylesheet" href="css\bootstrap.css">
  <script src="js/jquery-3.4.1.js"></script>
  <script src="js/validacao.js"></script>
</head>
<body>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4 mx-auto py-5">

        <h3>Login</h3>
        <hr>

        <form action="interformulario.php" method="post" id="formulario">

          <label>Nome:</label><br>
          <input type="text" name="nome" value="" class="form-control obrigatorio">
          <span class="text-danger"></span> <br>

          <label>Senha:</label><br>
          <input type="password" name="senha" value="" class="form-control obrigatorio">
          <span class="text-danger"></span>
          <br>

          <button type="submit" class="mt-3 btn btn-primary">Entrar</button>
          <br>
          <a href="#">Recuperar senha</a>

        </form>

      </div>
    </div>
  </div>

</body>
</html>
