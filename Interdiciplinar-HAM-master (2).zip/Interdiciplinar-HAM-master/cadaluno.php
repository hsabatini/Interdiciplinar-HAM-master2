<!DOCTYPE html>

<?php include 'partes/cabeca.php' ?>

  <body>

    <div class="container">

      <div class="row">
        <div class="col-md-4 mx-auto py-5">



          <h3>Cadastro de Aluno</h3>
          <hr>

          <form action="verificaraluno.php" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span> <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>RA:</label><br>
            <input type="number" name="ra" value="" class="form-control obrigatorio ra">
            <span class="text-danger"></span>
            <br>

            <label>Curso:</label><br>
            <input type="text" name="curso" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Turma:</label><br>
            <input type="text" name="turma" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confSenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <button type="submit" class="mt-3 btn btn-secondary">Confirmar cadastro</button><br>
            <!-- DE UMA TELA A OUTRA -->
            <!-- <a href="/Interdiciplinar-HAM-master/telaCadastro.php" class="mt-3 btn btn-primary" id="btnEntrar">
              Voltar para tela inicial
            </a> -->
            <br>

          </form>

        </div>
      </div>
    </div>

    <?php include 'partes/javascript.php'; ?>

    <script type="text/javascript">
        $(document).ready(function(){
          // Aqui vai seu código js/jquery

        });
    </script>


  </body>
</html>
