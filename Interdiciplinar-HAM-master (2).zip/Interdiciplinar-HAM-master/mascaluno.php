<!-- <script src="js/jquery.mask.js"></script>


<script type="text/javascript">

$(document).ready(function(){
  // $('.ra').mask('000.000.000.000')
  $('.ra').mask('000.000.000.000', {translation:  {'Z': {pattern: /[0-9]/, optional: true}}});
    // var SPMaskBehavior = function (val) {
    //   return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
    // },
    // spOptions = {
    //   onKeyPress: function(val, e, field, options) {
    //     field.mask(SPMaskBehavior.apply({}, arguments), options);
    //   }
    // };
    //
    //
    //
    // $('.ra').mask('0000000000');
  });
</script>
 
