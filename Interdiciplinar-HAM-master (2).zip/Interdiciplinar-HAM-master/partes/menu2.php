<!DOCTYPE html>
<html lang="" dir="ltr">
<head>
  <meta charset="utf-8">
  <title> TELA PARA LOGIN </title>
  <?php include 'partes/head.php' ?>
</head>
<body>

  <div class="container">
<div class="row bg-secondary">
  <div class="col-md">
    <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
    <?php include 'partes/head.php' ?>
  </div>
  <div class="col-md pl-5 pt-2 pb-3">
    <img src="http://200.17.98.122:8080/certificadosdeclaracoes/resources/img/paranavai-vertical.png" alt="" height="50">
  </div>
</div>

<div class="row bg-secondary p-2">
  <div class="col-md">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#"> </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item ">
            <!-- <a class="nav-link" href="#">Cadastrar Aluno </a> -->
            <a href="index.php?pagina=mostrarAtend">
              HÓRARIO DE ATENDIMENTO
            </a>
          </li>
          <li class="nav-item">
            <!-- <a class="nav-link" href="#">Cadastrar Professor</a> -->
            <a href="index.php?pagina=mostrarMoni">
              HORÁRIO DA MONITORIA
            </a>
          </li>
          <li class="nav-item">

        </ul>
      </div>
    </nav>

  </div>

</div>
<?php include 'partes/javascript.php' ?>
<script type="text/javascript">
    $(document).ready(function(){
      // Aqui vai seu código js/jquery

    });
</script>
</body>
</html>
