<div class="row bg-secondary">
  <div class="col-md ml-2 text-light m-4">
    <h4 class="ml-2 text-light m-2 "> Endereço: Rua, Avenida José Felipe Tequinha, 1400 - Jardim das Nacoes, Paranavaí - PR </h4>
 <h4 class="ml-2 text-light m-2 "> Telefone: (44) 3482-0110 </h4>
  </div>
</div>
