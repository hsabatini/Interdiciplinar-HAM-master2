<!DOCTYPE html>
<html lang="br" dir="ltr">
<head>
<meta charset="utf-8">
<title> TELA INICIAL </title>
<?php include 'partes/head.php' ?>
</head>
<div class="container">

  <!-- Inclui o menu/link neste lugar -->
  <?php include 'partes/menu.php' ?>

</div>
