<?php
@session_start();
include "conexao.php";
$_SESSION['email'] = $_POST['email'];
$_SESSION['ciap'] = $_POST['ciap'];
$email = $_POST['email'];
$curso = $_POST['ciap'];

$seletor = "SELECT * FROM cadprof WHERE email = '$email' AND ciap = '$ciap'";
$res = mysqli_query($con, $seletor);
$select = mysqli_fetch_assoc($res);

?>

            <form action="alterar2.php" name="form" method="post" class="pl-5 pt-5 pb-5 text-left w-50">
              <label>email: </label>
              <input type="text" name="email" value="<?php echo $select['email'];?>" required ><br>
              <label>ciap: </label>
              <input type="text" name="ciap" value="<?php echo $select['ciap'];?>" required ><br>

              <div class="text-center pr-5">
                <input type="hidden" name='idprof' value="<?php echo $select['idCadProf']; $select['email']; $select['ciap']; ?>" class="p-2 mt-1 btn-danger"></input>
                <button type="submit" name="button">Alterar Professor</button>

              </div>
            </form>
            <br>

            <br>
            <div class="p-4 m-4">

            </div>

</html>
