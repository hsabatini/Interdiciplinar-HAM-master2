<?php
include "conexao.php";
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$confSenha = $_POST['confSenha'];
$ciap = $_POST['ciap'];

$select_aluno = "SELECT * FROM cadaluno";
$result = mysqli_query($con, $select_aluno);
$array = mysqli_fetch_array($result);

if($array['nome'] == $nome){
  // alert("Usuário já cadastrado!");
}else {
  if($senha == $confSenha){

    $inserir = "INSERT INTO cadprof (nome, email, senha, confSenha, ciap ) VALUES ('$nome', '$email', '$senha', '$confSenha', '$ciap')";

    mysqli_query($con, $inserir);
  } else{
    echo "Senha incorreta";
  }
  // alert("Cadastrado com sucesso!");
  include "cadprof.php";
}

 ?>
