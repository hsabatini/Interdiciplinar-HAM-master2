<?php
@SESSION_START();
$nome = $_POST['nome'];
$ra = $_POST['ra'];
$email = $_POST['email'];
$curso = $_POST['curso'];
$turma = $_POST['turma'];
 ?>
<!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>TELA ALTERAR ALUNOS</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="datatable/datatables.min.css">


 </head>
   <body>
     <div class="container">

       <!-- Inclui o menu neste lugar -->
      <div class="row bg-secondary">
        <div class="col-md">
            <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
          </div>
      </div>

        <div class="row">
          <div class="col-md mx-auto py-5">

           <h3>ALTERAR CADASTRO</h3>
           <hr>

           <?php
           include 'conexao.php';
           include 'partes/config.php';


           $select = mysqli_query($con,"SELECT * FROM cadaluno WHERE nome = '$nome' AND email = '$email' AND turma = '$turma' AND curso = '$curso' AND ra = '$ra'");
           $array = mysqli_fetch_array($select);

            ?>

            <table id="teste" class="table table-striped table-bordered bg-secondary" style="width:100%">
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>RA</th>
                  <th>e-mail</th>
                  <th>curso</th>
                  <th>turma</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <td><?php echo $array['nome']; ?></td>
                <td><?php echo $array['ra']; ?></td>
                <td><?php echo $array['email']; ?></td>
                <td><?php echo $array['curso']; ?></td>
                <td><?php echo $array['turma']; ?></td>
                <td>
                  <input type="hidden" name="<?php $array['nome'] ?>" value="">
                  <input type="hidden" name="<?php $array['ra'] ?>" value="">
                  <input type="hidden" name="<?php $array['email'] ?>" value="">
                  <input type="hidden" name="<?php $array['curso'] ?>" value="">
                  <input type="hidden" name="<?php $array['turma'] ?>" value="">
                  <button type="button" name="button" href="alterar.php">Alterar</button>
                </td>
                <td></td>
              </tr>
            <?php  ?>
           </tbody>
            </table>

         </div>
       </div>
     </div>

     <!-- "Importa" os códigos/bibliotecas javascript -->
      <?php include 'partes/javascript.php' ?>


      <script>
      $(document).ready( function () {
        $('#teste').DataTable();
      } );
      </script>


   </body>
 </html>
