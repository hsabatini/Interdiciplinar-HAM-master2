<!DOCTYPE html>
<html lang="br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TELA DE CADASTRO DO MONITOR</title>
        <?php include 'partes/head.php' ?>

  </head>
  <body>
    <div class="container">

      <!-- Inclui o menu neste lugar -->
      <div class="row bg-secondary">
        <div class="col-md">
          <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 mx-auto py-5">
          <h3>Cadastro de Monitor</h3>
          <hr>
          <form action="" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>RA:</label><br>
            <input type="number" name="ra" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confsenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
<br>

            <a href="/Interdiciplinar-HAM-master/horarios/hrMonitoria.php" class="btn btn-primary" id="btnHrMonitoria">
              Informações para Monitoria
            </a>

                <!-- "Importa" os códigos/bibliotecas javascript -->
                <?php include 'partes/javascript.php' ?>

                <script type="text/javascript">
                    $(document).ready(function(){
                      // Aqui vai seu código js/jquery

                    });
                </script>
  </body>
</html>
