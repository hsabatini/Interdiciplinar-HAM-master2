<?php
include "conexao.php";
$nome = $_POST['nome'];
$email = $_POST['email'];
$ra = $_POST['ra'];
$senha = $_POST['senha'];
$confSenha = $_POST['confSenha'];

$select_cadmonitor = "SELECT * FROM cadmonitor";
$result = mysqli_query($con, $select_cadmonitor);
$array = mysqli_fetch_array($result);

if($array['nome'] == $nome){
  // alert("Usuário já cadastrado!");
}else {
  if($senha == $confSenha){

    $inserir = "INSERT INTO cadmonitor (nome, email, senha, confSenha, ra ) VALUES ('$nome', '$email', '$ra', '$senha', '$confSenha' )";

    mysqli_query($con, $inserir);
  } else{
   echo "Confira a senha novamente!";
  }
  // alert("Cadastrado com sucesso!");
  include "cadmonitor.php";
}

 ?>
