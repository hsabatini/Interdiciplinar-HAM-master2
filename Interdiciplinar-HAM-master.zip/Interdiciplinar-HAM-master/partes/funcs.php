<?php
function navega ($pagina){
  switch ($pagina) {
    case 'cadaluno':
      require 'paginas/cadaluno.php';
      break;
    case 'incluiraluno':
      require 'paginas/incluiraluno.php';
      break;
    default:
      require 'telaCadastro.php';
      break;
  }
}

function conecta(){
  return mysqli_connect(host, user, pass, banco);
}

?>
