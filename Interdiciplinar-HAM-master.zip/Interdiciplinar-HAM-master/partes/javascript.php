<!-- Importação do jquery -->
<script src="js/jquery-3.4.1.js" ></script>
<!-- importação do popper js -->
<script src="js/popper.min.js"></script>
<!-- impotação do Js do bootstrap -->
<script src="js/bootstrap.min.js"></script>


      <script src="datatable/datatables.min.js" ></script>
<script src="js/validacao.js"></script>
