<?php
function navega ($pagina){
  switch ($pagina) {
    case 'cadprof':
      require 'paginas/cadprof.php';
      break;
    case 'incluirprof':
      require 'paginas/incluirprof.php';
      break;
    default:
      require 'telaCadastro.php';
      break;
  }
}

function conecta(){
  return mysqli_connect(host, user, pass, banco);
}

?>
