<?php
include "conexao.php";
$nome = $_POST['nome'];
$email = $_POST['email'];
$ciap = $_POST['ciap'];
$senha = $_POST['senha'];
$confSenha = $_POST['confSenha'];


$select_cadprof = "SELECT * FROM cadprof";
$result = mysqli_query($con, $select_cadprof);
$array = mysqli_fetch_array($result);


if($array['nome'] == $nome){
  // alert("Usuário já cadastrado!");
}else {
  if($senha == $confSenha){

    $inserir = "INSERT INTO cadprof (nome, email, ciap, senha, confSenha ) VALUES ('$nome', '$email', '$ciap', '$senha', '$confSenha')";

    mysqli_query($con, $inserir);
    include "horarios/hrAtendimento.php";
  } else{
   echo "Confira a senha novamente!";
  }
  // alert("Cadastrado com sucesso!");
  // include "cadprof.php";
}

 ?>
