<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TELA DE CADASTRO DE ALUNOS</title>
    <?php include 'partes/head.php';
  include 'mascaluno.php' ;
  ?>
  <body>
  </head>
    <div class="container">

      <!-- Inclui o menu neste lugar -->
     <div class="row bg-secondary">
       <div class="col-md">
           <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
         </div>
     </div>

       <div class="row">
         <div class="col-md-4 mx-auto py-5">

          <h3>Cadastro de Aluno</h3>
          <hr>

          <form action="verificaraluno.php" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span> <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>RA:</label><br>
            <input type="number" name="ra" value="" class="form-control obrigatorio ra">
            <span class="text-danger"></span>
            <br>

            <label>Curso:</label><br>
            <input type="text" name="curso" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Turma:</label><br>
            <input type="text" name="turma" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confSenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <button type="submit" class="mt-3 btn btn-primary">Confirmar cadastro</button><br>
            <a href="/Interdiciplinar-HAM-master/telaCadastro.php" class="mt-3 btn btn-primary" id="btnEntrar">
              Voltar para tela inicial
            </a>
            <br>

          </form>

        </div>
      </div>
    </div>

    <!-- "Importa" os códigos/bibliotecas javascript -->
    <!-- <?php include 'partes/javascript.php' ?>

    <script type="text/javascript">
        $(document).ready(function(){
          // Aqui vai seu código js/jquery

        });
    </script> -->

  </body>
</html>
