<!DOCTYPE html>
<html lang="br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> TELA DE CADASTRO DE PROFESSOR</title>
        <?php include 'partes/head.php' ?>

  </head>
  <body>

    <div class="container">

            <!-- Inclui o menu neste lugar -->
            <div class="row bg-secondary">
              <div class="col-md">
                <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
              </div>
            </div>
      <div class="row">
        <div class="col-md-4 mx-auto py-5">

          <h3>Cadastro de Professor</h3>
          <hr>

          <!-- PRECISAMOS DEFINIR - get ou post -->
          <form action="verificarprof.php" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>CIAP:</label><br>
            <input type="text" name="ciap" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Disciplina(as):</label><br>
            <input type="text" name="disciplina" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>


            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confSenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>


            <!-- Adicionar um do lado do outro!!! -->


            <button type="submit" class="btn btn-primary" id="btnHrAtendimento">
             next
           </button>
          </form>
    </div>
    <!-- "Importa" os códigos/bibliotecas javascript -->
    <?php include 'partes/javascript.php' ?>

    <script type="text/javascript">
        $(document).ready(function(){
          // Aqui vai seu código js/jquery

        });
    </script>

  </body>
</html>
