<!DOCTYPE html>
<html lang="" dir="ltr">
<head>
  <meta charset="utf-8">
  <title> TELA PARA LOGIN </title>
</head>
<body>
   <div class="container">
<?php include 'partes/head.php' ?>
<div class="row bg-secondary">

    <div class="col-md">
      <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
    </div>
    <div class="col-md pl-5 pt-2 pb-3">
      <img src="http://200.17.98.122:8080/certificadosdeclaracoes/resources/img/paranavai-vertical.png" alt="" height="50">
    </div>
  </div>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
<ul class="navbar-nav">
  <li class="nav-item">
    <a href="/Interdiciplinar-HAM-master/telaLista.php" class="btn btn-light">
       Lista de alunos
    </a>
  </li>
<li class="nav-item ">
<a href="/Interdiciplinar-HAM-master/login.php" class="btn btn-light" id="btnCadastro">
Logar como aluno
</a>
</li>
<li class="nav-item">
<a href="/Interdiciplinar-HAM-master/login.php" class="btn btn-light" id="btnCadastro">
Logar como monitor
</a>
</li>
<li class="nav-item">

<a href="/Interdiciplinar-HAM-master/Login.php" class="btn btn-light" id="btnCadastro">
LOGAR MONITOR
</a>
</li>

</ul>
</div>
</nav>
<?php include 'partes/carrosel.php' ?>

<?php include 'partes/rodape.php' ?>
</div>

  <!-- "Importa" os códigos/bibliotecas javascript -->
  <?php include 'partes/javascript.php' ?>
  <script type="text/javascript">
      $(document).ready(function(){
        // Aqui vai seu código js/jquery

      });
  </script>

</body>
</html>
